# How a spot is read

This is the process of [@bighatprops](https://x.com/bighatprops), CourtAI's founder, distilled from 131
of his write-ups (2026-03 to 2026-10). Each spot is a short **case**: a thesis,
the evidence in the order below, then the risks. Every step is a question;
answer it with the tools that fit, and when a step does not bear on the spot,
say so in one line. [EXAMPLES.md](EXAMPLES.md) has his own absence-driven bets
and the misreads behind the checks here; read it before writing the first case.

## The case, in order

1. **Thesis: why is this line off?** One or two sentences naming the channel
   (minutes, usage, or both) and the gap between the line and tonight's role.
   The usual gaps: the line is priced off last season or an injury-riddled one;
   the book has not caught up with tonight's absence; the role changed and the
   line did not; or a **system** spot (step 7). An absence can argue the under
   too: the line rises with the news while his minutes ceiling does not, the
   usage goes to someone else, or a returning teammate (IN) shrinks the role.
2. **Market: is the price still there?** Set tonight's line against his
   with-him and without-him averages: how much of the move has it absorbed?
   Check every book and app on his row of the board: the scenarios' "beat X of
   N" counts one provider's line, which can be the outlier. A soft book behind
   the news, a line out of step, or one already moving is part of the case; a
   line already past the value is a pass. A line below both averages is a
   pricing question about him, not the absence; say which one the case is.
   When the read is about volume, the volume market is the cleaner bet: 3PA
   over FGA over PTS or 3PM, potential assists behind assists.
3. **Minutes (the opportunity channel): what is his floor and ceiling
   tonight?** A read from rotation history, not a projection: his minutes with
   and without the absent player (the middle half of the without games is the
   honest range), his recent minutes and starts, who competes for the minutes,
   and blowout or tanking risk. Compare the line with the role he plays
   tonight: if he starts tonight, his without-him figure on this team is the
   comparison, not this season's bench numbers. A starter who plays the same
   minutes either way gained no opportunity.
4. **Usage (the role channel): where does the absent player's volume go?**
   Name what he leaves (his shots, playmaking, boards), then who takes it: the
   teammates whose usage and per-36 rise with him off the floor and whose
   numbers rise in the games he missed. Ask whether the roles overlap: a
   low-usage forward frees little for a star guard, whatever the split says.
   Trust volume over efficiency: a usage or shot-volume bump is the signal, a
   hot or cold shooting stretch is noise.
5. **Rate and minutes together: does the line need more than his role gives?**
   Set his rate without the absent player beside his likely minutes, and ask
   whether clearing the line needs more minutes than the games without him gave
   him (over), or fewer than his usual floor (under).
6. **Comparable games: how often has he cleared tonight's line in this role?**
   Start with every game without him against tonight's line; its card is
   usually the spot's graphic. Then narrow to games like tonight: who is out and
   who plays (`without`, `with`), a minutes band, opponents like tonight's on
   the play type that matters (`vs`). A minutes filter picks his good games, so
   set it beside how often he reaches that floor. When last season was an
   outlier, the season before or the career rate is the better comparison; say
   which.
7. **Matchup: does the defense fit his archetype?** His Diet against what the
   opponent allows (`get_matchup` with `player` and `market`), head-to-head
   games, and the opponent's own absences tonight. The recurring **systems**
   are the strongest reads, ridden until the book adjusts; name one when a spot
   is one:
   - a PnR ball handler against a defense that does not double or help;
   - a stretch or pick-and-pop big against a drop center who sags (3PA overs);
   - a poor shooter a scheme leaves open (3PA and FGA overs; assists for the
     doubled star);
   - a star guard against a blitzing team likely to blow his team out or be
     blown out (FGA unders);
   - a PnR roll-man center against a defense that stops the roll (unders).
8. **Game script**: the spread from the web with its source, stakes, tanking,
   rest. "Spread not found" rather than a guess.
9. **Risks: what loses this?** Small samples, foul trouble, a minutes cap, a
   returning teammate, shooting variance, a line already moved, an unconfirmed
   lineup. Name them; a real but not fatal risk argues for a lighter bet.

## Before trusting a split

**Sample comes before the story.** Keep the number behind every claim visible.
A handful of games, or a few hundred minutes on one side of an on/off, is a
hint, never the case; say it is thin beside the number. A channel is shown when
it holds in more than one place (the games he missed and the on/off, or last
season and this one); one source alone makes at most a **thin** spot. A big
change on a small sample is usually noise: ask whether it makes basketball
sense.

**Context comes before trusting any split.** Each question here comes from a
misread on a real slate (see EXAMPLES.md).

- **Who else was out in those games?** If another regular missed most of the
  same games, his absence is in the split too: isolate it (`without` both, or
  `with` the other) or call the credit shared. A teammate who joined mid-season
  was "out" in every game before he arrived; a player traded away is in his old
  team's "with" games. Set `from_date` to the later of the two players' first
  games with the team.
- **When were those games, and why did he miss them?** A rookie's healthy
  scratches, an early-season stretch, a tank or a minutes cap all read like an
  absence. Check when the missed games fell and his minutes between them.
- **Is it the same team now?** A teammate gone, a new starter, a new coach or
  this season's rotation outranks last season's split; a few games of this
  season's scoring do not. When the player's role or the players around him
  changed (he or the absent player switched teams, a regular who shared the job
  arrived or left), drop last season's split and read the spot from this
  season and the news, usually as a watch-list angle. When the change points the
  same way as the bet, you may keep the split, but the change is the spot's open
  question, which caps it at **lean**.
- **How long has he been out?** After a long streak, "without him" is the
  current rotation and the book has seen it; ask whether the line still sits at
  the old role. Count the streak in this season's games only.
- **Is the teammate listed himself?**

## Backing a read

A bettor often writes a case from feel. The agent's edge is that it can check
every read: for each claim, find the figure that confirms or contradicts it and
write the figure. When nothing can speak to it (coachspeak, the eye test,
preseason tape), keep it and mark it `read:`. Who is on the roster, who starts
and this season's minutes are facts; look them up.

| The read | The figure that backs it |
|---|---|
| "should play 30+ minutes" | his minutes and starts in games the injured player missed |
| "the usage has to go somewhere" | usage and per-36 with the injured player off the floor, and who else gains |
| "great matchup" | his Diet against the opponent's ranks, and his record against similar defenses |
| "low line" / "strange line" | the other books on the same market, and his record against this number |
| "close game" / "blowout risk" | the spread from the web, with its source |
| "hot recently" / "in a slump" | his last 5 and 10 against the line |

A read the figure contradicts is the most useful thing the drill finds: say so,
and let it change or drop the case.
