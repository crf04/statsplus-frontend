# How a spot is read

This is the process of [@bighatprops](https://x.com/bighatprops), CourtAI's founder, distilled from 131
of his write-ups (2026-03 to 2026-10). Each spot in the brief is a short **case**: a thesis, then
the evidence in the order below, then the risks. Every step is a question; answer
it with the tools that fit, and when a step does not bear on this spot (or the
data cannot answer it), say so in one line rather than padding it.
[EXAMPLES.md](EXAMPLES.md) has his own absence-driven bets, each tagged
with the steps it shows; read it before writing the first case.

## The case, in order

1. **Thesis: why is this line off?** One or two sentences naming the gap between
   the line and the role tonight. The usual gaps: the line is priced off last
   season or an injury-riddled one; the book has not caught up with tonight's
   absence; the role changed (a starter is out, a new system, a player traded
   away) and the line did not ("strange line after X was just ruled out"); or a
   **system** spot (below) the book still has not priced. An absence can argue
   the under as well as the over: the line rises with the news while the
   player's minutes ceiling does not, or the usage goes to someone else, or the
   returning teammate (IN) shrinks the role back.
2. **Market: is the price still there?** Start from where tonight's line
   sits against his with-him and without-him averages: how
   much of the move the line has absorbed, and why a line outside both averages
   moved. Compare the line with the other books and
   apps for the same market (`query_game_logs` and `get_matchup` list every
   posted line and price). A soft book behind on tonight's news, a line out of step with
   the rest, or one already moving (an opener 26.5 now 23.5) is part of the case;
   a line that has already moved past the value is a reason to pass. When the read
   is about volume, the volume market is the cleaner bet: 3PA over FGA over PTS
   or 3PM, potential assists behind assists.
3. **Minutes: what is his floor and ceiling tonight?** Not a projection: a read
   from rotation history. His minutes with the injured player and without him
   (the middle half of the without games is the honest range), his recent
   minutes, his starts, who else competes for the minutes, and a blowout or
   tanking risk (`get_rotation` `player`, `team` + `without`; his minutes in the games
   without him).
   Name a range, with the games behind it.
4. **Usage: where does the absent player's volume go?** First, is there any? Name
   what he leaves a game (his season line), then who takes it: the
   teammates whose starts and minutes rise in the games they played without him,
   and whose usage and per-36 rise with him on the bench. A teammate whose move
   shows in neither needs another explanation. Then ask whether his role overlaps the teammate's: a low-usage forward frees little for
   a star guard, whatever the split says. Then rule out confounders: if another
   regular also missed those games, the split is partly his, and the drill should
   isolate the absence (`without` both, or `with` the other). Usage and per-36 rates
   with the injured player off the floor against on it (`get_on_off`, the
   scenario's USG context), FGA or 3PA for shooting markets. Trust volume over
   efficiency: a usage or shot-volume bump is the signal, a cold shooting stretch
   is noise.
5. **Rate × minutes: does the line need more than his role gives?** Turn his
   without-him rate per 36 into the minutes needed to clear the line (line ÷ rate
   × 36), and set that against the range from the minutes step. It is a concern
   when the line needs more minutes than the without games gave
   him (for an over) or fewer than his usual floor (for an under).
6. **Comparable games: how often has he cleared tonight's line in this role?**
   Start with every game without him against tonight's line (`query_game_logs`
   `without`; it counts every game against tonight's posted line); its card is
   usually the spot's graphic. Then narrow it to games that look like tonight: the
   injured player out (`without`), and the teammates who play tonight in
   (`with`), a minutes floor or band like tonight's (`query_game_logs`
   `minutes`; the usual form is "with 26+ minutes, over in 27/38"), and opponents like tonight's on the play type
   that matters (`vs`, e.g. "playing 30-42 minutes against bottom-15 PnR
   ball-handler defenses, over in 16 of 21"), with the sample size. Recent
   head-to-head volume (FGA, 3PA, potential assists in so many minutes) is scheme
   evidence even in one game. When last season was an
   outlier (injury, a different team), the season before or the career rate is
   the better comparison; say which one you used.
7. **Matchup: does the defense fit his archetype?** His Diet (play types, shot
   zones, shot types) against what the opponent allows (`get_matchup` `player`
   `market`), and head-to-head games this season. Name the opponent's absences
   tonight and what each changes (a starting center out for the bigs' REB, a
   point-of-attack defender out for the guard's PTS); the screen reads only the
   teammates' side, so this is the step that catches them. Read the scheme: a drop
   coverage or a weak PnR defense for a ball handler, a sagging big for a
   pick-and-pop center, a rim protector against a cutter. The recurring
   **systems** are the strongest reads, ridden until the book adjusts:
   - a PnR ball handler against a defense that does not double or help (the
     usage funnels to him);
   - a stretch or pick-and-pop big against a drop center who sags (3PA overs);
   - a poor shooter a scheme leaves open, as Mazulla's Celtics do (3PA and FGA
     overs for him; assists for the doubled star);
   - a star guard against a blitzing team likely to blow his team out or be
     blown out (FGA unders);
   - a PnR roll-man center against a defense that stops the roll (unders).
   Name the system when a spot is one.
8. **Game script: does the game state help or hurt?** Spread, stakes and blowout
   risk, tanking, seeding stakes, rest. CourtAI carries no spreads; use the
   spread from the web research with its source, and call it unknown only when
   the research found none.
9. **Risks: what loses this?** Small samples, foul trouble, a minutes cap, a
   returning teammate, shooting variance, a line already moved, an unconfirmed
   lineup (a tanking team can summon a player ruled out). Name them; do not
   explain them away. A risk that is real but not fatal argues for a lighter bet.

## Backing a read

A bettor often writes a case from feel: a read about minutes, role or matchup
that is right more often than not but has no number beside it. The agent's edge
is that it can check every one. For each claim in a case, find the figure that
would confirm or contradict it, and write the figure; when nothing can speak to
it (coachspeak, the eye test, preseason tape, rebound chances), keep it as a
read and say "read:" so the reader can tell judgement from evidence. A read is
only for what no tool or source can check: who is on the roster, who starts and
this season's minutes are facts, so look them up.

| The read | The figure that backs it |
|---|---|
| "should play 30+ minutes" / "minutes are secure" | his minutes and starts in games the injured player missed (`get_rotation` `player` or `team` + `without`) |
| "the usage has to go somewhere" / "the X show" | usage and per-36 with the injured player off the floor (`get_on_off`), and who else gains (`get_rotation` `team` + `without` stats) |
| "great matchup" / "weak against spot-up" | his Diet against the opponent's ranks (`get_matchup` `player` `market`), and his record against similar defenses (`query_game_logs` `vs`) |
| "low line" / "strange line" | the other books and providers on the same market, and his record against this exact number |
| "close game" / "blowout risk" | the spread from the web research, with its source |
| "hot recently" / "in a slump" | his last 5 and 10 against the line (`query_game_logs` `last_n`) |

A read that the figure contradicts is the most useful thing the drill finds: say
so, and let it change or drop the case.

## Writing it

- Title the spot with the bet: player, side, line and market, e.g. "Tyrese
  Maxey o20.5 PTS", with the book's prices and the game on the price line. The
  side is where the evidence points; the reader sizes and places the bet.
- Then a few short paragraphs that walk the steps that bear on the spot, each
  claim with its figure, sample and season, and the limit beside the number.
- A spot whose case does not hold up after the drill is written as a pass with
  the reason, when the reason teaches something, or left out.
