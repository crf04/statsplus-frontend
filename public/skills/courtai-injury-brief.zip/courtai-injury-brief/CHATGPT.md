# Running the CourtAI injury brief in ChatGPT

ChatGPT has no skill format, so the brief runs as a ChatGPT **Project** whose
files are this skill.

1. Add CourtAI to ChatGPT as a plugin (https://courtai.app/connect, ChatGPT tab).
2. Create a Project, for example "Injury brief".
3. Add the three files from this folder to the Project's files: `SKILL.md`,
   `ANALYSIS.md` and `EXAMPLES.md`.
4. Paste this into the Project's instructions:

   ```text
   When I ask for the injury brief (or which spots to target given who is out
   tonight), follow SKILL.md in this project's files step by step, using the
   CourtAI plugin for every NBA number and web search for this season's
   news. Read ANALYSIS.md for how to build each case and EXAMPLES.md for real
   examples. Write the brief in the chat, games
   first, then the graded spots, then publish it as a CourtAI report and give me
   the link. CourtAI reports facts; the grades are your reading of them, and I
   make the final call.
   ```

5. In a chat inside the Project, turn on the CourtAI plugin and ask:
   "Run the injury brief for tonight."
