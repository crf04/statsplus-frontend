# Drill menu

The CourtAI connector's tools, by the question each answers. Arguments are each
tool's own; a wrong argument comes back with an error naming the right one.
Every call counts against your account's per-minute and per-day limits, so
screen first and drill only the candidates.

| Question | Tool and arguments |
|---|---|
| Who is listed tonight, with what status and minutes? | `get_injuries` `date` (optionally `team`) |
| Which games are on a date? | `get_slate` `date` (a large answer: it also ranks the slate's Matchups; for a team's past game dates the web is cheaper) |
| What does each absence do to each rotation teammate? | `get_injury_scenarios` `date` + `game`, one call per game (a whole-slate call leaves games out); `player` for one injured player's full list. "Beat X of N" counts one provider's line |
| Who starts and whose minutes and stats change without him? | `get_rotation` `team` + `without` (or `player` + `without`) |
| Does it hold with two teammates out? | `get_rotation` `team` + `without: [a, b]`; `query_game_logs` `without: [a, b]` |
| How did he do in the games the player missed, against tonight's line? | `query_game_logs` `player`, `market`, `without: [injured]`; with no `line` it counts every game against tonight's posted line and lists every book's line and price |
| How has he done in a minutes band, or against defenses like tonight's? | `query_game_logs` `minutes: [low, high]`, `vs: [{"filter": "Play type: PnR ball handler", "ranks": [16, 30]}]` (ranks 1-30, 30 = allows the most) |
| What is his usage and per-36 with the player on the bench? | `get_on_off` `team`, `off: [injured]` (or `on`), `season` |
| How does tonight's opponent defend his market? | `get_matchup` `game`, `date`, `player`, `market`: his Diet against what the opponent allows, plus every posted line and price. Always pass `market`; without it the answer covers every market and is very large |
| Who started and played what minutes in one game this season? | `get_rotation` `game` + `date` (find the dates with `get_slate`). Early in a season this can be the only this-season data CourtAI has; `team` and `player` without `game` read the season its figures cover |
| A Questionable player: what if he sits, what if he plays? | `get_injury_scenarios` `date`, `player` (both branches) |
| What did he do over a whole past season? | `get_season_stats` `player`, `season` |
| Recent form against the line? | `query_game_logs` `last_n` |

`vs` ranks are the whole season's as of today, not each game's own, so a record
filtered by them leans on hindsight; say so beside the number.

## The line

Without a `line`, `query_game_logs` counts every game against the player's
posted line for tonight's game (the answer names the line and its book). Name a
`line` to count against a different number, such as one book's line that is out
of step with the rest. When no line is posted for him, say so and report the
spot without a line record.

## Windows

`without` is game-level: a game counts when he did not appear, whatever the
reason. A teammate who joined mid-season was "out" in every game before he
arrived. In `query_game_logs`, set `from_date` to his first game with the team;
`get_rotation` and `get_injury_scenarios` cannot cut by date, so say the split
includes the games before he came (or after a teammate was traded away).

## Cards

Where the client shows them, `query_game_logs` (a record against the line),
`get_on_off` (the team's per-36 table), `get_matchup`, `get_injuries` and a
one-game `get_rotation` draw a card. Lead a spot with the card that carries its
case, usually its game logs without the absent player against tonight's line.
