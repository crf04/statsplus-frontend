# Worked examples: bets built on an absence

Write-ups by [@bighatprops](https://x.com/bighatprops), CourtAI's founder, where an injury or a return drove the
bet, trimmed to the reasoning. They are a reference for **process**, not a
standard of evidence: several bullets are reads with no figure behind them ("Jazz
great matchup", "should play 30+ min", "minutes should be very secure"). Follow
their shape and build on them: where he would write a read, back it with a
figure (see "Backing a read" in [ANALYSIS.md](ANALYSIS.md)), or keep it as a read
and label it one. Each example ends with the steps it shows and, where it has
one, the read the data could back.

## Out: the line has not caught up

**Jerami Grant O 10.5 Pts**
- Strange line after Camara was just ruled out.
- Over in L21/29 with 24+ min, should play 30+ min here.
- Heat are weak against spot-up.

Steps: thesis (book behind the news), minutes, comparable games (minutes floor),
matchup. Reads to back: "should play 30+ min" (his minutes in games Camara
missed), "Heat are weak against spot-up" (the Spot up rank and his share of it).

**Brooks O 12.5 PA**
- Over in 31/48 (65%) games with 26+ min, should be good today in a close spread.
- Sengun is out, averages 19.66 PA/36 with him off the court. Over in 3/4 without
  him, with him shooting 2/13 in the one miss.
- OKC gives up the 3rd most C&S threes.

Steps: comparable games, usage (per 36 with the injured player off the floor),
a small without-him sample stated with its one miss explained, matchup, game
script.

**Jaden McDaniels O 9.5 Pts**
- Low line after getting in foul trouble last two games.
- When playing 26+ minutes this year, he's over in 27/38 (71%).
- Most of this is with KAT, who is out.
- Jazz great matchup.

Steps: thesis (line priced off a fluky stretch), comparable games, and a check that
the comparable games came with the absent player playing. Reads to back: "Jazz
great matchup" (his Diet against Utah), and the record rerun without KAT.

**De'Aaron Fox o18.5 Pts (-106 DK)**
- Wemby out, it's time for Fox to show why he makes his money.
- Averages 22 a game without Wemby and with Castle this year. Over in 5/6.
- Brook sits in a drop, should be a perfect game for Fox to attack.

Steps: comparable games filtered on who is out *and* who plays, matchup (a system
spot: ball handler against a drop big).

**Trae Young O 5 FTM**
- Pushed or over in 31/45 (69%) games this year.
- Jalen Johnson out, should be the Trae show.
- Pistons foul a lot, 5th most in L15, especially the PnR ball handler.

Steps: comparable games, usage funnel, matchup on the market itself (fouls drawn
for free throws). Read to back: "should be the Trae show" (his usage and FTA per
36 with Jalen Johnson off the floor).

**Hartenstein O 10.5 RA (-115 DK)**
- Over in 21/22 (96%) playing 24+ min, which he has averaged 29 in the last 5.
- Mitch Rob is still injured, and even if he plays will barely eat into Hart's
  minutes.

**Dillon Brooks O 6 3PA**
- Grizzlies allow the most C&S 3s.
- Minutes should be very secure without Jabari.
- 6+ 3PA in 16/27 games with 26+ min.

**Austin Reaves O 4.5 Ast (Bet365 -125)**
- Not widely available and mispriced on Bet365. With LeBron gone, Reaves is the
  clear secondary playmaker, and the primary one when Luka sits.
- 7.2 assists a game with Luka and without LeBron last year, over 4.5 in 10/12.
  On/off: 7.4 Ast/36 with LeBron off the floor.

Steps: market (one book out of line), usage (on/off), comparable games filtered
on both who is out and who plays.

**Tari Eason O 15.5 PRA (-112 Bet365)**

Fred and Steven Adams are OUT today on a B2B, Tari had a fully healthy offseason and Ime said he looks more explosive and improved after an up and down season last year.

His minutes should be a lot safer here, think he should be good for 25+. Averaged 17.6 PRA/25 minutes last year.

With 22-30 minutes last year he was over in 19/27 (70%) of games, Hawks are a decent matchup, play super fast and with both teams on a B2B might see some lazy defense here.

## Out: the absence does not mean the over

**Jaxson Hayes U 9.5 RA (Underdog -132)**
- Nurkic is out, but Hayes is not good enough to play 30+ minutes, and there
  should be some JJJ at the 5 to close.
- Preseason he played about 14 minutes in the first half with the starters, so a
  ceiling of about 28 minutes.
- At 8.8 RA/36 he would have to severely outpace that rate. Over in 1/12 last
  year playing 22-30 minutes.

Steps: minutes ceiling, rate × minutes, comparable games in a band. The
absence moved the line up; the role did not move enough.

**Derrick Jones Jr u9.5 Pts (-126 Novig)**
- Clippers have everyone healthy, so his minutes are not secure; a max of 30.
- Wemby out: Kornet's drop leads to more ball-handler usage, not his.
- With Kawhi, Garland and JC all in, 5.9 points on 10.6% usage.

Steps: usage goes to someone else (the ball handlers), minutes, comparable
games with tonight's lineup.

## In: a teammate returns and the role shrinks

**Daniss Jenkins U 16.5 PRA (-115 DK)**
- With Cade in the preseason, 8 minutes a game in the first half with the starters.
- With Cade last year playing 15-22 minutes, 13.3 PRA and under in 19/25.
- 25.4 PRA/36 with Cade, so he needs about 23 minutes to clear 16.5.
- Boston is a bad matchup.

Steps: the plays branch read as a case (his with-him figures), minutes, rate ×
minutes, comparable games, matchup.

## Role change from a lineup move

**Fred VanVleet U 3.5 Reb**
- Since Amen joined the starting lineup, 4, 3, 3, 5, 3 rebound chances: that
  volume does not match a 3.5 line.
- Kings allow the 6th-fewest rebounds.

Steps: the role change read through underlying volume (rebound chances), matchup.
CourtAI has no rebound chances or potential assists; say so and use the
nearest stat it has.

## Misreads the checks came from

Each is a split that looked like a spot until its context was read. The checks
in ANALYSIS.md ("Before trusting a split", step 3) exist because of them.

**Maxime Raynaud out, Zach LaVine's points (when and why he missed).** Raynaud's
8 misses in 2025-26 all fell in his rookie month, at about 12 minutes a game in
between. LaVine's scoring in those games was early-season LaVine, not a Raynaud
effect: his usage was flat with Raynaud on or off the floor.

**Austin Reaves's assists without Luka Dončić (same team now?), 2026-10-28.**
His assists without Luka came with LeBron still on the roster. LeBron leaving
points the same way as the bet (more of the ball is his), so the split stayed as
evidence, with the roster change named as the open question: a lean at most.

**Ayo Dosunmu o16.5 PTS (which role is the line priced against?),
2026-10-28.** He averaged 12 points off the bench this season, so 16.5 looked
priced past his role. In his 7 Minnesota games without Edwards he played about
33 minutes and scored 18.7, over 16.5 in 6. Tonight's role was the starter's.
