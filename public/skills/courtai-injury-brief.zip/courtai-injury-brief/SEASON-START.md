# Early in a season

In October and November, CourtAI's game logs, splits and team rotations can
still cover last season (`query_game_logs` with the new `season` then refuses,
naming the season it has), and rosters have moved since. Last season's splits
stay the main evidence for what an absence does; this season decides whether
they still apply.

**Check rosters before the first split.** For every team with a news absence:

- `query_game_logs` for a player with `season` set to this season lists his
  games, minutes and team so far.
- `get_rotation` with `game` and `date` gives one game's starters, minutes and
  stints this season; one call for the team's latest game is enough (find the
  date on the team's ESPN schedule page). Without `game`, `get_rotation` and the
  other tools read the season CourtAI's figures cover, even where a tool says
  "the current season".
- The web adds the moves behind it: arrivals and departures, a returning
  player, a trade, a waiver, a rest day, tonight's projected starters
  (Rotowire's lineups page), and the spread (ESPN's game page; once a game
  tips, ESPN drops the line). Searches for a date this close often return old
  seasons, so check each result's date.

A player who missed all of last season may not be in CourtAI's player catalog;
read him from this season's games and the news. The minutes on the injury
report are from the season CourtAI's figures cover, possibly with a former
team, so check where a player is now before sorting him. A scenarios answer
with no rotation teammates for him is the quickest sign he changed teams.

A roster or role change that breaks last season's split outranks it (see "Is
it the same team now?" in [ANALYSIS.md](ANALYSIS.md)); a split from last
season's roster can be wrong for every absence on that team.
