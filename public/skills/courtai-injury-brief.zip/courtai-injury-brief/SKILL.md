---
name: courtai-injury-brief
description: Read tonight's NBA injury report with the CourtAI connector, work out whose role and numbers actually change when a player sits, check that against tonight's posted lines, and write a short graded brief with CourtAI's cards as its graphics. Use when the user asks for an injury brief, which spots to target given who is out, or who benefits from tonight's absences.
---

# CourtAI injury brief

You are researching spots for the user. A **spot** is one teammate and one market that moves when a listed player sits. **OUT** is a player ruled out. **IN** is a Questionable or Doubtful player who plays: his teammates fall back to their with-him figures.

Each spot answers two questions. The **effect**: does the absence change the
teammate's role, through **minutes** (he plays longer, an opportunity spot) or
**usage** (he does more in the same minutes, a usage spot)? The **price**: has
tonight's line caught up? A spot is worth a look when the effect is real on a
real sample, in its context, and the line has not absorbed it. CourtAI reports
facts; every judgement is yours, and the brief shows it. A spot is a place to
look, not a pick.

This needs the **CourtAI connector** (https://courtai.app); without its tools,
say so and stop. Web search supplies rosters, news and spreads; without it, say
so at the top of the brief, read this season from CourtAI's own games, and mark
the spread unknown. The connector has a per-minute and per-day limit, so screen
first and drill only the candidates. The brief's format below overrides each
tool's own format hints.

The loop is **screen → read → drill → write → publish**. How to read one case
is in [ANALYSIS.md](ANALYSIS.md), the single source for every check on a spot;
real absence-driven bets and past misreads are in [EXAMPLES.md](EXAMPLES.md).
In October and November, or whenever CourtAI's figures cover last season, read
[SEASON-START.md](SEASON-START.md) before the first split.

**Update run.** When an earlier brief from today exists (its brief and
research notes), start from it: re-pull the injury report and tonight's lines,
then screen, read and drill only the absences that are new or changed, and keep
the rest unless its line moved. The opening leads with what changed since then:
new Out or Doubtful players, upgrades, line moves. Finish before the first
remaining tip. A game that has already tipped gets one line, and its spots are
`tipped`.

## 1. Screen

The date is today in US Eastern unless the user names one.

1. `get_injuries` for the date. The official report is the authority on
   status; when news disagrees, use the report and mention the news. If nobody
   is Out, Doubtful or Questionable, or the slate has no games, say so in one
   line and stop.
2. `get_slate` for the games. If every game has tipped, say so and offer the
   next slate's brief.
3. `get_board` once per market, `PTS`, `REB`, `AST`, `3PM` and `PRA` to start,
   following each `cursor` to the last page, and another market when a
   candidate needs it. These tables are where every line and price comes from.
4. `get_injury_scenarios` with each `game`, one call per game (a whole-slate
   call leaves most games out). Read its **Started in his place** and
   **Minutes jumps** lists: a backup under 15 minutes who starts without him is
   often the night's best spot. Its minutes count a game the teammate also
   missed as 0, so check games played before reading a drop. When an answer is
   too large, call again with `player` for the news absences, highest minutes
   first, and say which you did not read.
5. Sort every listed player. He is **news** when he has played this season and
   is newly out, or is a Questionable regular. He is **long or unreadable** when
   his absence began last season or in the preseason, he is two-way or on G
   League assignment, or he is new to his team: the current rotation already
   plays without him. Set one aside only after you have checked whether the
   line has caught up with the current role.
6. For each news absence, highest minutes first:
   - `get_rotation` with `team` and `without`: who started and whose minutes
     and stats changed in the games he missed. Skip one only for size, and say
     which.
   - `get_on_off` with his `team` and him `off`: every teammate's usage and
     per-36 rates with him on and off the floor. Every spot shows this card.

Done when every listed player is read (steps 4 and 6) or sorted as long or
unreadable with the reason.

## 2. Read

**Go wide, then narrow.** For each news absence, list every teammate whose role
moves on either channel: the scenarios' flagged rows, Started in his place,
Minutes jumps, the rotation's without-him stats, and the on/off. Give each
teammate every market that moved for him, not only the flagged one. Then list
the players on the other team the absence helps: a missing rim protector opens
the paint and the glass, a missing point-of-attack defender opens the guards.
That list is the game's section of the brief and carries more names than the
spots. Only then go narrow: build a case for each gainer whose line has not
caught up, using every check in [ANALYSIS.md](ANALYSIS.md).

Done when every absence is a candidate spot with the question it leaves open,
or set aside with a one-line reason. A night with no candidate is reported as
that.

## 3. Drill

Answer each candidate's open question with the CourtAI tools; the choice of
tool is a judgement, and the calls' cards are the brief's graphics. Make the
call whose card carries the case, usually his game logs without the absent
player against tonight's line. Gotchas the tool descriptions leave out:

- `get_matchup` with `player` is for the opponent's defense against how he
  scores; always pass `market`. Lines come from the board.
- `vs` ranks are the whole season's as of today, so a record filtered by them
  leans on hindsight; say so beside the number.
- `query_game_logs` `with`/`without` can cut by date (`from_date`); the
  rotation and scenario splits cannot, so say so when a roster changed
  mid-season.
- `query_game_logs` with no `line` counts every game against tonight's posted
  line and lists every book's price; when he has no posted line, say so and
  report the spot without a line record. It is also where lines come from when
  `get_board` is missing from the chat's tools (say so in the brief).

Done when every candidate's question is answered or marked unanswerable with
the reason.

## 4. Write the brief

The brief has these parts, in this order; publishing (step 5) maps them to tabs.

1. **Opening**, with no heading of its own: one sentence on the news absences
   and who gains, then one or two lines on what the market already moved and
   the limit that matters most.
2. **Games**: one short section for every game on the slate, with its spread:
   who is out on both teams, then every gainer from the wide pass with the
   markets that moved and the figure that shows each. A quiet game gets one line
   saying why nothing changes.
3. **Spots**, strongest first, after an at-a-glance table (grade, bet, the one
   figure that carries it). Each spot: the bet as its title ("Tyrese Maxey
   o20.5 PTS") with the best price and the game; two or three short paragraphs
   walking the case per [ANALYSIS.md](ANALYSIS.md), every claim with its figure,
   sample and season or marked `read:`; what loses it; its cards, the one that
   carries the case first.
4. **Watch list**: angles that are not cases yet (one or two games, a few
   hundred on/off minutes, a read with no figure, a pricing question about the
   player rather than the absence), one line each with what would make it one
   and, when it names a line, its book and price.
5. **Set aside**: every other listed player, one short clause each with why.
6. **Sources** for every fact from outside CourtAI, and the report time used.

**Grades**, by how well the evidence holds: **strong** (the channel shows in
more than one place on a real sample, its context holds, the record agrees and
nothing material is against); **lean** (a real case with one open question,
named); **thin** (a real case on a real sample that shows in one place only);
**pass** (looks like a spot but isn't, when the reason teaches something);
**tipped** (the game started before the brief; say the evidence grade in the
text). A case resting on one or two games goes on the watch list. Write up every
spot with a real case; a busy slate gets many, and a handful on a night with
several news absences means the research stopped early.

Every Out, Doubtful or Questionable player appears once, as a spot's subject or
set aside, and a spot that rests on two absences names both; Available and
Probable players need no entry. Give each figure once: a gainer's full numbers
sit in his spot (or his game's section when he is not a spot), and every other
mention points there in a few words. Use plain words and no
tool names. Quote prices as posted, in American odds with the book; the best
price is the highest American odds for that side across every book and app,
skipping one far out of line with the rest (say which).

**Final pull.** Just before you hand over, call `get_injuries` again and screen,
read and drill anyone whose status changed or who is newly listed. Then
re-price each graded spot with `query_game_logs` for his market and no `line`,
and put the sportsbook `as_of` (in ET, read as "no later than") on its price
line, not a separate line. When that time is older than a ruling the spot rests on, say the book may
not have caught up. DFS apps and prediction markets carry no time; say "no time
given".

## 5. Publish

If `publish_report` is missing, say the brief stays in chat. Otherwise, unless
the user said not to, call it with:

- `report`: `title` ("Injury brief · Sunday, October 25"), `date`, `opening`,
  `skill` (`{"name": "Injury brief", "url": "https://courtai.app/skills/injury-brief"}`),
  and `tabs`: **Games** (`tiles`: title with spread, subtitle with who is out,
  `bullets` as `[gainer, figure]`, `body`, `cards`, `sources`); **Spots**
  (`rows`: `tag` grade, `title` bet, `subtitle` price and game, `key` figure,
  `body`, `watch` what loses it, `cards`, `sources`); **Watch list** (`list`,
  left out when empty); **Set aside** (`list`).
- `calls`: every call a card shows, as `{id, tool, args}` with the arguments you
  sent. CourtAI reruns each against the daily limit, so list only calls you
  made, that drew a card, and that an item names.
- `show_author`: false unless the user asks to be named.

If the publish is refused, fix what it names and publish again. Give the user
the link.
