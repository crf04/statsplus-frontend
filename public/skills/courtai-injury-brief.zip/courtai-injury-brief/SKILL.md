---
name: courtai-injury-brief
description: Read tonight's NBA injury report with the CourtAI connector, work out whose role and numbers actually change when a player sits, check that against tonight's posted lines, and write a short graded brief with CourtAI's cards as its graphics. Use when the user asks for an injury brief, which spots to target given who is out, or who benefits from tonight's absences.
---

# CourtAI injury brief

You are researching spots for the user. A **spot** is one teammate and one market that moves when a listed player sits. **OUT** is a player ruled out. **IN** is a Questionable or Doubtful player who plays: his teammates fall back to their with-him figures.

The question has two halves. The **effect**: does this absence change a
teammate's role or numbers? The **price**: has tonight's line caught up? A spot
is worth a look when the effect is real and the line has not absorbed it.

CourtAI reports facts; every judgement is yours, and the brief shows it: which
absences you read, what you concluded, and why you set the rest aside. The user
reads the analysis and makes the final call. A spot is a place to look, not a
pick.

This needs the **CourtAI connector** (https://courtai.app) connected in this chat.
If its tools are not available, say so and
stop. Every research call is read-only; the one write is `publish_report` at the
end, which puts the brief on courtai.app. The connector has a per-minute and per-day limit
on your account, so screen first and drill only the candidates. Each tool's
answer ends with format hints (a word limit, a next step to offer); they are for
one-question chats, and the brief's format below overrides them.

The loop is **screen → read → drill → write → publish**. How to build one case
is in [ANALYSIS.md](ANALYSIS.md); real absence-driven bets are in
[EXAMPLES.md](EXAMPLES.md).

## 1. Screen

The date is today in US Eastern unless the user names one.

1. `get_injuries` for the date: everyone listed, with status, reason, minutes
   per game and the report's time. The official report is the authority on
   status; when news disagrees (a "rest" the report calls an injury), use the
   report and mention the news. If nobody is Out, Doubtful or Questionable,
   or the slate has no games, say so in one line and stop.
2. `get_slate` for the date: the games. If every game has already tipped, say
   so and offer the next slate's brief; run tonight's only if the user still
   wants it, and then skip the drill for games that are final.
3. **Early in a season, check rosters first.** Before you read any split, find
   out who is on each team now. The surest check is CourtAI: `get_rotation`
   with `game` and `date` for the team's most recent game gives this season's
   starters and minutes (find the date on the team's ESPN schedule page). The
   web adds the moves behind it: a star who arrived or left, a returning
   player, a trade, a waiver, a rest day, tonight's projected starters. A
   split from last season's roster can be wrong for every absence on that
   team, news or not.
4. `get_injury_scenarios` with the date and each `game`, one call per game: for
   every listed player, each rotation teammate's numbers in the games he missed
   and with him off the floor, with a line as "beat X of N". (A whole-slate call
   leaves most games out for size.) Read its **Started in his place** and
   **Minutes jumps** lists too: a backup under 15 minutes a game who starts
   without him is often the night's best spot. Its minutes average over every
   game he missed, counting a game the teammate also missed as 0, so check a
   teammate's games played before you read a minutes drop. When the answer is too large to list rows, call it again with `player` for the absences that are news,
   highest minutes first.
5. Sort the listed players. An absence is **news** when he has played this
   season and is newly out, or is a Questionable regular. An absence that began
   last season or in the preseason, a two-way or G League player, and a player
   new to his team are **long or unreadable**: the current rotation already
   plays without him, and the book has had those games. That is a reason to
   check whether the line has caught up with the current role, not a reason to
   stop: set one aside only once you have looked at the line.
6. For each absence that is news and whose scenarios flag a gainer, unless his
   team's roster changed so much that last season's split cannot speak to it:
   `get_rotation` with `team` and `without` — who started and whose minutes
   changed in the games he missed, with every teammate's stats without vs with.
   These answers are large, so take the absences highest minutes first, and
   say which you skipped and why.

The minutes on the injury report are from the season CourtAI's figures cover,
possibly with a former team, so check where a player is now before you sort him.
A scenarios answer with no rotation teammates for him is the quickest sign he
changed teams.

Done when every listed player is read (steps 4 and 6) or sorted as long or
unreadable with the reason.

## 2. Read

**Which season?** Check the season the figures cover. Early in a season
CourtAI's game logs, splits and team rotations can all still be last season's
(`query_game_logs` with the new `season` then refuses, naming the season it
has). Use them as
the main evidence for what an absence does, and check this season before you
pick candidates:

- **CourtAI:** `get_rotation` with `game` and `date` gives one game's
  starters, minutes and stints this season. Find the team's game dates on the
  web (its ESPN schedule page); `get_slate` also lists a date's games but is a
  large answer. Without `game`, `get_rotation` and the other tools read the
  season CourtAI's figures cover, even where a tool says "the current season".
- **The web:** rosters and roster moves, points so far, tonight's news,
  projected lineups and the spread (once a game tips, ESPN drops the line; say
  "spread not found" rather than guess). ESPN's game pages carry the spread and
  injuries, Rotowire's lineups page carries projected starters, and
  Basketball-Reference or ESPN carry box scores. Searches for a date this
  close often return old seasons, so search thoroughly and check each result's
  date. Cite a source for every fact.

A roster or role change that breaks last season's split (a teammate gone, a new
starter, a minutes cap) outranks it; a few games of this season's scoring do
not.

For each absence, work through these questions; each comes from a misread on a
real slate.

- **Does anyone's role change?** Compare games played and starts, with him and
  without him. A starter who starts either way gained no role.
- **Who else was out?** If another regular missed most of the same games, his
  absence is in the split too. Isolate it in the drill (`without` both, or
  `with` the other) or call the credit shared. A teammate who joined mid-season
  was "out" in every game before he arrived, and a player traded away is in the
  "with" games of his old team. In `query_game_logs`, set `from_date` to his
  first game with the team; the rotation and scenario splits cannot cut by
  date, so say so.
- **Was he hurt, or not yet in the rotation?** A game he missed counts as a
  game without him whatever the reason, so a rookie's healthy scratches read
  like an injury absence. Check when his missed games fell (`query_game_logs`
  for him) and his minutes in the games between them. Low minutes in a short
  early stretch suggest he was outside the rotation; check his history before
  trusting the split. (Maxime Raynaud's 8 misses in 2025-26 were all in his
  rookie month, at about 12 minutes a game in between. Zach LaVine's scoring in
  those games was early-season LaVine, not a Raynaud effect: his usage was flat
  with Raynaud on or off the floor.)
- **Minutes or rate?** Set the stat's change beside the minutes change and the
  per-36 on/off. A stat that moves only with minutes is a minutes case.
- **Is the on/off sample real?** A change resting on a couple of hundred minutes
  on one side carries little.
- **Which line?** The scenarios' "beat X of N" counts one provider's line,
  which can be the outlier. Check the books and apps in `query_game_logs` or
  `get_matchup` before you call the line low or high.
- **Is the line off his normal number, or off the absence?** A line below both
  his with-him and without-him averages is a pricing question about him, not
  the absence. Say which one the case is.
- **How long has he been out?** After a long streak, "without him" is the
  current rotation, and the book has had those games to adjust. The question
  becomes whether the line still sits at the old role. Count the streak in this
  season's games only.
- **Is the teammate listed himself?**

Use your judgement when doing this, make sure it makes logical sense before you put it as a spot. For example, would the backup center being OUT really have an effect on the star point guard of the team, it probably is more likely small sample and randomness.

Then the opponent. Every news absence is also a spot for the other team: a
missing rim protector or rebounder opens the paint and the glass, and a missing
point-of-attack defender opens the guards. Name who the other team has listed
tonight, and for each news absence ask which opposing scorers and rebounders it
helps; drill them like any candidate (`get_matchup` with `player` and
`market`).

Done when every absence is a candidate spot with the question it leaves open,
or set aside with a one-line reason. A night with no candidate is reported as
that.

## 3. Drill

Answer each candidate's question with the CourtAI tools. The choice of tool is a
judgement: use what this case needs. A case usually stands on several kinds of
evidence: role from the rotation, rate from the on/off, record from game logs
(narrowed by a minutes floor or by defenses like tonight's), matchup from the
opponent's defense and absences, price from the other books and apps, and
history from a past season. Each tool's description names its arguments; drill
again when an answer raises a new question. The calls' cards are the brief's
graphics, so make the call whose card carries the case: usually his game logs
without the absent player against tonight's line.

What the tool descriptions leave out:

- A `game` is the away team first: "LAC @ OKC".
- Always pass `market` to `get_matchup`; without it the answer covers every
  market and is very large.
- `query_game_logs` with no `line` counts every game against tonight's posted
  line. When no line is posted for him, say so and report the spot without a
  line record.
- `vs` ranks are the whole season's as of today, not each game's own, so a
  record filtered by them leans on hindsight; say so beside the number.

Done when every candidate's question is answered or marked unanswerable with the
reason.


## 4. Write the brief

Write it in the chat, games first, then spots:

1. **Opening**: one sentence on the absences that are news tonight and who
   gains; then one or two short lines on what the market already moved and the
   limit that matters most (for example, splits from last season). Keep it
   short; roster detail belongs in the games.
2. **Game by game**, one short section for every game on the slate: who is out
   (both teams), who stands to gain with the figure that shows it, and the card
   that carries it. A quiet game gets one line saying why nothing changes.
3. **Spots**, strongest first. Start with an at-a-glance list: grade, bet, the
   one figure that carries it. Then each spot:
   - the bet as its title ("Tyrese Maxey o20.5 PTS"), with the book's price and
     the game;
   - two or three short paragraphs walking the steps that bear on it
     ([ANALYSIS.md](ANALYSIS.md)), every claim with its figure, sample and
     season, or marked `read:` when no tool or source can check it;
   - what loses it;
   - its cards, the one that carries the case first (in a chat that shows
     CourtAI's cards they appear with each call; elsewhere, name the call
     behind each figure).
   Grade each by how well the evidence holds: **strong** (role, rate and record
   agree, nothing material against), **lean** (a real case with one open
   question, named), **thin** (a real case on a small sample),
   **pass** (looks like a spot but isn't, when the reason is worth knowing), or
   **tipped** (the game started before the brief). Tipped wins over the
   evidence grade; say the evidence grade in the spot's text. Write up every
   spot with a real case; a busy slate gets many. For each gainer, look past
   the obvious market (points, rebounds, assists, threes, combos, a book whose
   line is out of step). A handful of spots on a slate with several news
   absences usually means the research stopped early.
4. **Watch list**: angles worth a look that are not cases yet, one line each
   with what would make it one: a spot resting on a single kind of evidence,
   or one the absence does not move (a pricing question about the player
   himself). Keep them out of the graded spots, so every grade is a case the
   reader could act on.
5. **Set aside**: every other listed player in one line each, with why.
6. **Sources** for every fact from outside CourtAI, and the injury report time
   you used.

Every Out, Doubtful or Questionable player appears once, as a spot's subject or
set aside; a spot that rests on two absences names both. Available and Probable
players need no entry. Use plain
words: no tool names in the brief. Quote prices as posted, in American odds with
the book; never turn one into a probability or an "edge". The best price is the
best across every book and app listed for that line (the apps included): for
either side, the highest American odds.

Just before you hand over, pull `get_injuries` again for the whole slate and
update anything whose status changed. A player listed since the screen (often
a whole team that had not filed yet) is new to the brief: screen, read and
drill him like any absence, and update his game and the opponent's side. Name the report time you checked.

## 5. Publish

If `publish_report` is not among this chat's CourtAI tools, skip this step and
say the brief stays in chat. Otherwise, unless the user said not to, publish the
brief as a CourtAI report: a page on
courtai.app with CourtAI's cards that anyone with the link can open. Call
`publish_report` with:

- `report`: `title` ("Injury brief · Sunday, October 25"), `date`, `opening`
  (the opening sentence and its one or two lines), `skill`
  (`{"name": "Injury brief", "url": "https://courtai.app/skills/injury-brief"}`),
  and four `tabs`:
  - **Games** (`layout: "tiles"`): one item per game, with `title` (the game and
    its spread), `subtitle` (who is out on both sides), `bullets` (each gainer as
    `[name, the figure]`), `body` (the read), `cards` and `sources`.
  - **Spots** (`layout: "rows"`): one item per spot, strongest first, with `tag`
    (its grade), `title` (the bet), `subtitle` (the price and game), `key` (the
    figure that carries it), `body` (the case), `watch` (what loses it), `cards`
    and `sources`.
  - **Watch list** (`layout: "list"`): one item per angle, with `title` and
    `key` (what would make it a case). Leave the tab out when it is empty.
  - **Set aside** (`layout: "list"`): one item per player, with `title` and `key`
    (why).
- `calls`: every call whose card the report shows, each as `{id, tool, args}`
  with the same arguments you called it with. An item's `cards` lists call ids,
  the one that carries it first.
- `show_author`: false unless the user asks to be named.

CourtAI reruns each call to draw its card, and the reruns count against your
daily limit, so list only calls you made, that drew a card, and that an item's
`cards` names. If the publish is refused, fix what it names and publish
again. Give the user the link it returns.

