---
name: courtai-injury-brief
description: Read tonight's NBA injury report with the CourtAI connector, work out whose role and numbers actually change when a player sits, check that against tonight's posted lines, and write a short graded brief with CourtAI's cards as its graphics. Use when the user asks for an injury brief, which spots to target given who is out, or who benefits from tonight's absences.
---

# CourtAI injury brief

You are researching spots for the user. A **spot** is one teammate and one market that moves when a listed player sits. **OUT** is a player ruled out. **IN** is a Questionable or Doubtful player who plays: his teammates fall back to their with-him figures.

The question has two halves. The **effect**: does this absence change a
teammate's role or numbers? It comes through two channels: **minutes** (he
plays longer, an opportunity spot) and **usage** (he does more in the same
minutes, a usage spot). The **price**: has tonight's line caught up? A spot is
worth a look when the effect is real on a real sample, in its context, and the
line has not absorbed it.

CourtAI reports facts; every judgement is yours, and the brief shows it: which
absences you read, what you concluded, and why you set the rest aside. The user
reads the analysis and makes the final call. A spot is a place to look, not a
pick.

This needs the **CourtAI connector** (https://courtai.app) connected in this chat.
If its tools are not available, say so and
stop. It also uses web search for rosters, news and spreads; without it, say
so at the top of the brief, read this season from CourtAI's own games, and
mark the spread unknown. Every research call is read-only; the one write is `publish_report` at the
end, which puts the brief on courtai.app. The connector has a per-minute and per-day limit
on your account, so screen first and drill only the candidates. Each tool's
answer ends with format hints (a word limit, a next step to offer); they are for
one-question chats, and the brief's format below overrides them.

The loop is **screen → read → drill → write → publish**. How to build one case
is in [ANALYSIS.md](ANALYSIS.md); real absence-driven bets are in
[EXAMPLES.md](EXAMPLES.md).

## 1. Screen

The date is today in US Eastern unless the user names one.

1. `get_injuries` for the date: everyone listed, with status, reason, minutes
   per game and the report's time. The official report is the authority on
   status; when news disagrees (a "rest" the report calls an injury), use the
   report and mention the news. If nobody is Out, Doubtful or Questionable,
   or the slate has no games, say so in one line and stop.
2. `get_slate` for the date: the games. If every game has already tipped, say
   so and offer the next slate's brief; run tonight's only if the user still
   wants it, and then skip the drill for games that are final.
3. `get_board` for the date, once per market the brief checks: `PTS`, `REB`,
   `AST`, `3PM` and `PRA` to start, and another market (a combo, threes
   attempted) when a candidate needs it. Each answer is every posted line for
   that market across the slate, one table per game with a column per book and
   app; when it returns a `cursor`, call again with it until the last page. These
   tables are where every spot's line and price come from: never call
   `get_matchup` per player to look up lines. `get_board` with no `market` lists
   the markets posted that day. If `get_board` is not among this chat's CourtAI
   tools, take each candidate's lines from `query_game_logs` with no `line`,
   which lists every book and app for his market, and say so in the brief.
4. **Early in a season, check rosters first.** Before you read any split, find
   out who is on each team now. The quickest check is CourtAI's game logs for
   this season: `query_game_logs` for a player with `season` set to this
   season lists his games, minutes and team so far. For a team's starters and
   minutes, `get_rotation` with `game` and `date` gives one game; one call for
   the team's latest game is enough, so budget one per team with a news absence
   (find the date on the team's ESPN schedule page). The web adds the moves
   behind it: a star who arrived or left, a returning player, a trade, a
   waiver, a rest day, tonight's projected starters. A player who missed all of
   last season may not be in CourtAI's player catalog at all; read him from
   this season's games and the news. A split from last season's roster can be
   wrong for every absence on that team, news or not.
5. `get_injury_scenarios` with the date and each `game`, one call per game: for
   every listed player, each rotation teammate's numbers in the games he missed
   and with him off the floor, with a line as "beat X of N". (A whole-slate call
   leaves most games out for size.) Read its **Started in his place** and
   **Minutes jumps** lists too: a backup under 15 minutes a game who starts
   without him is often the night's best spot. Its minutes average over every
   game he missed, counting a game the teammate also missed as 0, so check a
   teammate's games played before you read a minutes drop. When the answer is
   too large to list rows, call it again with `player` only for the absences
   that are news, highest minutes first, and at most a few per game; say which
   you did not read per player.
6. Sort the listed players. An absence is **news** when he has played this
   season and is newly out, or is a Questionable regular. An absence that began
   last season or in the preseason, a two-way player or one on G League
   assignment, and a player new to his team are **long or unreadable**: the current rotation already
   plays without him, and the book has had those games. That is a reason to
   check whether the line has caught up with the current role, not a reason to
   stop: set one aside only once you have looked at the line.
7. For each absence that is news and whose scenarios flag a gainer, unless his
   team's roster changed so much that last season's split cannot speak to it:
   `get_rotation` with `team` and `without` — who started and whose minutes
   changed in the games he missed, with every teammate's stats without vs with.
   These answers are large, so take the absences highest minutes first, and
   say which you skipped and why. This call is the main source for the wide
   pass in step 2: skip one only for size, never to save calls for the drill.
8. For each absence that is news, `get_on_off` with his `team` and him `off`:
   every teammate's usage and per-36 rates with him on and off the floor.
   Always make this call. The scenarios show on/off only for their scored
   rows, and the card needs this call.

The minutes on the injury report are from the season CourtAI's figures cover,
possibly with a former team, so check where a player is now before you sort him.
A scenarios answer with no rotation teammates for him is the quickest sign he
changed teams.

Done when every listed player is read (steps 5, 7 and 8) or sorted as long or
unreadable with the reason.

## 2. Read

**Which season?** Check the season the figures cover. Early in a season
CourtAI's game logs, splits and team rotations can all still be last season's
(`query_game_logs` with the new `season` then refuses, naming the season it
has). Use them as
the main evidence for what an absence does, and check this season before you
pick candidates:

- **CourtAI:** `get_rotation` with `game` and `date` gives one game's
  starters, minutes and stints this season. Find the team's game dates on the
  web (its ESPN schedule page); `get_slate` also lists a date's games but is a
  large answer. Without `game`, `get_rotation` and the other tools read the
  season CourtAI's figures cover, even where a tool says "the current season".
- **The web:** rosters and roster moves, points so far, tonight's news,
  projected lineups and the spread (once a game tips, ESPN drops the line; say
  "spread not found" rather than guess). ESPN's game pages carry the spread and
  injuries, Rotowire's lineups page carries projected starters, and
  Basketball-Reference or ESPN carry box scores. Searches for a date this
  close often return old seasons, so search thoroughly and check each result's
  date. Cite a source for every fact.

A roster or role change that breaks last season's split (a teammate gone, a new
starter, a minutes cap) outranks it; a few games of this season's scoring do
not.

**Go wide, then narrow.** The wide pass is per game. For each absence that is
news, list every teammate whose role moves on either channel: the scenarios'
flagged rows, **Started in his place** and **Minutes jumps**, and the
`get_rotation` `team` + `without` stats, and his usage and per-36 rates from
the on/off (step 1.8). Give each teammate every market that
moved for him (points, rebounds, assists, threes, PRA, shot attempts), not only
the one the scenarios flagged. Then list the players on the other team the
absence helps. That list is the game's section of the brief, and it carries
more names than the spots. Only then go narrow: drill the gainers whose line
has not caught up.

For each absence that is news, start from the two channels. This is a read,
not arithmetic: weigh what the evidence shows and say it in plain words.

1. **Who gets his minutes?** Who started and who played more in the games he
   missed (`get_rotation` `team` + `without`, the scenarios' **Started in his
   place** and **Minutes jumps**), and who is playing those minutes this season
   (one-game rotations). That is an **opportunity spot**: the teammate does
   what he already does, for longer. Ask whether tonight's minutes look like
   those games: his starts, rotation news, a minutes cap, blowout risk. A
   starter who starts and plays the same minutes either way gained no
   opportunity.
2. **Who gets his touches?** Who shot more, assisted more and had higher usage
   with him off the floor (`get_on_off`; the scenarios' per-36 and usage
   context), and does that show in the games he missed too. That is a **usage
   spot**: the same minutes, a bigger role. First name what the absent player
   actually did (shots, playmaking, boards), then who on this roster does that
   job: a low-usage forward frees little for a star guard, whatever the split
   says. Trust volume over efficiency: a usage or shot-volume bump is the
   signal, a hot or cold shooting stretch is noise.

A teammate can gain on one channel or both; say which. Then go granular by
channel: an opportunity spot favours the markets that follow minutes (every
counting stat, and rebounds for a big), and a usage spot favours the markets
whose numbers rose, the volume market over the result (shot attempts over
points, potential assists over assists). Only then the line, the record, the
matchup and the price.

**Sample comes before the story.** Keep the number behind every claim visible,
and never build a case on a small one.

- A handful of games without him, or a few hundred minutes or fewer on one
  side of an on/off, is a hint to check elsewhere, never the case. Say it is
  thin beside the number. A case that rests on one or two games goes on the
  watch list, not among the graded spots, however big the jump.
- A channel is shown when it holds in more than one place: the games he missed
  and the on/off, or last season and this season's games. One source alone,
  on a real sample, makes at most a **thin** spot.
- A big change on a small sample is usually noise or context, not a role
  change. Ask whether it makes basketball sense: would the backup center being
  out really move the star point guard's numbers? More likely small sample and
  randomness.

**Context comes before trusting any split.** Each of these comes from a misread
on a real slate.

- **Who else was out in those games?** If another regular missed most of the
  same games, his absence is in the split too. Isolate it in the drill
  (`without` both, or `with` the other) or call the credit shared. A teammate
  who joined mid-season was "out" in every game before he arrived, and a
  player traded away is in the "with" games of his old team. The same holds
  for the gainer: if he joined mid-season, his games for his old team count
  as games "without" the absent player. In `query_game_logs`, set `from_date`
  to the later of the two players' first games with the team. The rotation and
  scenario splits cannot cut by date, so say so.
- **When were those games, and why did he miss them?** A game he missed counts
  as a game without him whatever the reason, so a rookie's healthy scratches,
  an early-season stretch, a tank or a minutes cap after an injury all read
  like an absence. Check when his missed games fell (`query_game_logs` for him)
  and his minutes in the games between them. (Maxime Raynaud's 8 misses in
  2025-26 were all in his rookie month, at about 12 minutes a game in between.
  Zach LaVine's scoring in those games was early-season LaVine, not a Raynaud
  effect: his usage was flat with Raynaud on or off the floor.)
- **Is it the same team now?** A teammate gone, a new starter, a new coach or
  this season's rotation can break last season's split, and that outranks it;
  a few games of this season's scoring do not. Drop last season's split, rather
  than discount it, when the player's role or the players around him changed:
  the absent player or the teammate is on a new team, or a regular who shared
  the job (the other ball handler, the other big) has arrived or left. Then
  read the spot from this season's games and news alone, which usually makes it
  a watch-list angle rather than a graded spot. When the change points the same
  way as the bet (the other ball handler left, so more of the ball is his), you
  may keep last season's split as evidence, but name the change as the spot's
  open question, which caps it at **lean**. (Austin Reaves, 2026-10-28: his
  assists without Luka Dončić came with LeBron still on the roster.)
- **How long has he been out?** After a long streak, "without him" is the
  current rotation, and the book has had those games to adjust. The question
  becomes whether the line still sits at the old role. Count the streak in this
  season's games only.
- **Is the teammate listed himself?**

Then the price checks:

- **Which line?** The scenarios' "beat X of N" counts one provider's line,
  which can be the outlier. Check the books and apps on his row of the
  market's board before you call the line low or high.
- **Is the line off his normal number, or off the absence?** A line below both
  his with-him and without-him averages is a pricing question about him, not
  the absence. Say which one the case is.
- **Which role is the line priced against?** Compare the line with the role
  he plays tonight. If he starts tonight, his without-him figure on this team
  is the comparison, not this season's bench numbers. (Ayo Dosunmu,
  2026-10-28: he averaged 12 points off the bench this season, so 16.5 looked
  priced past his role. In his 7 Minnesota games without Edwards he played
  about 33 minutes and scored 18.7, over 16.5 in 6.)

Then the opponent. Every news absence is also a spot for the other team: a
missing rim protector or rebounder opens the paint and the glass, and a missing
point-of-attack defender opens the guards. Name who the other team has listed
tonight, and for each news absence ask which opposing scorers and rebounders it
helps; drill them like any candidate (`get_matchup` with `player` and
`market`).

Done when every absence is a candidate spot with the question it leaves open,
or set aside with a one-line reason. A night with no candidate is reported as
that.

## 3. Drill

Answer each candidate's question with the CourtAI tools. The choice of tool is a
judgement: use what this case needs. A case usually stands on several kinds of
evidence: role from the rotation, rate from the on/off, record from game logs
(narrowed by a minutes floor or by defenses like tonight's), matchup from the
opponent's defense and absences, price from the other books and apps, and
history from a past season. Each tool's description names its arguments; drill
again when an answer raises a new question. The calls' cards are the brief's
graphics, so make the call whose card carries the case: usually his game logs
without the absent player against tonight's line. Every spot also shows its
on/off card (the `get_on_off` call from step 1.8), because injury scenarios
draw no card. When one side of the split is small, show the card anyway and
give the minutes beside the figure.

What the tool descriptions leave out:

- A `game` is the away team first: "LAC @ OKC".
- `get_matchup` with `player` is for a candidate's matchup (the opponent's
  defense against how he scores), not his lines: the board already has every
  book and app. Always pass `market`; without it the answer covers every
  market and is very large.
- `query_game_logs` with no `line` counts every game against tonight's posted
  line. When no line is posted for him, say so and report the spot without a
  line record.
- `vs` ranks are the whole season's as of today, not each game's own, so a
  record filtered by them leans on hindsight; say so beside the number.

Done when every candidate's question is answered or marked unanswerable with the
reason.


## 4. Write the brief

Write it in the chat, games first, then spots:

1. **Opening**: one sentence on the absences that are news tonight and who
   gains; then one or two short lines on what the market already moved and the
   limit that matters most (for example, splits from last season). Keep it
   short; roster detail belongs in the games.
2. **Game by game**, one short section for every game on the slate: who is out
   (both teams), then every gainer from the wide pass on both teams. Give each
   gainer the markets that moved and the figure that shows each, then the card
   that carries the strongest. The spots are drawn from this list; the list is
   not limited to the spots. A quiet game gets one line saying why nothing
   changes.
3. **Spots**, strongest first. Start with an at-a-glance list: grade, bet, the
   one figure that carries it. Then each spot:
   - the bet as its title ("Tyrese Maxey o20.5 PTS"), with the book's price and
     the game;
   - two or three short paragraphs walking the steps that bear on it
     ([ANALYSIS.md](ANALYSIS.md)): first the channel (minutes, usage or both)
     and the evidence for it, then the rest; every claim with its figure,
     sample and season, or marked `read:` when no tool or source can check it;
   - what loses it;
   - its cards, the one that carries the case first (in a chat that shows
     CourtAI's cards they appear with each call; elsewhere, name the call
     behind each figure).
   Grade each by how well the evidence holds: **strong** (the channel shows in
   more than one place on a real sample, its context holds, the record agrees
   and nothing material is against), **lean** (a real case with one open
   question, named), **thin** (a real case on a real sample that so far shows
   in one place only),
   **pass** (looks like a spot but isn't, when the reason is worth knowing), or
   **tipped** (the game started before the brief). Tipped wins over the
   evidence grade; say the evidence grade in the spot's text. Write up every
   spot with a real case; a busy slate gets many. For each gainer, look past
   the obvious market: read every stat in his without-him games against that
   market's board (points, rebounds, assists, threes, combos, a book whose line
   is out of step). A handful of spots on a slate with several news
   absences usually means the research stopped early.
4. **Watch list**: angles worth a look that are not cases yet, one line each
   with what would make it one: a spot resting on a small sample (one or two
   games, a few hundred on/off minutes), on a read with no figure behind it,
   or one the absence does not move (a pricing question about the player
   himself). An angle that names a line gives its book and price, as a spot
   does. Keep them out of the graded spots, so every grade is a case the
   reader could act on.
5. **Set aside**: every other listed player in one line each, with why.
6. **Sources** for every fact from outside CourtAI, and the injury report time
   you used.

Every Out, Doubtful or Questionable player appears once, as a spot's subject or
set aside; a spot that rests on two absences names both. Available and Probable
players need no entry. Use plain
words: no tool names in the brief. Quote prices as posted, in American odds with
the book; never turn one into a probability or an "edge". The best price is the
best across every book and app listed for that line (the apps included): for
either side, the highest American odds. Skip a price far out of line with
every other source for the same line (one app at +250 while the books sit near
even), say which one you skipped, and quote the best of the rest.

Just before you hand over, pull `get_injuries` again for the whole slate and
update anything whose status changed. A player listed since the screen (often
a whole team that had not filed yet) is new to the brief: screen, read and
drill him like any absence, and update his game and the opponent's side. Name the report time you checked.

Then re-price every graded spot, after that final injury pull: call
`query_game_logs` again for the spot's player and market with no `line`, and
quote the prices from that answer. Each game's books are polled on their own
clock, about hourly, and the answer's sportsbook `as_of` is the newest move any
book reported, so read it as "no later than". Put the `as_of` (in ET) on every
spot's price line. When a book's `as_of` is older than a ruling the spot rests
on, such as a player ruled out after the lines were posted, say beside the price
that the book may not have caught up and that the reader should check it before
acting. DFS apps and prediction markets carry no time in the answer; they are
polled every 5 to 8 minutes, so say "no time given" rather than guess.

## 5. Publish

If `publish_report` is not among this chat's CourtAI tools, skip this step and
say the brief stays in chat. Otherwise, unless the user said not to, publish the
brief as a CourtAI report: a page on
courtai.app with CourtAI's cards that anyone with the link can open. Call
`publish_report` with:

- `report`: `title` ("Injury brief · Sunday, October 25"), `date`, `opening`
  (the opening sentence and its one or two lines), `skill`
  (`{"name": "Injury brief", "url": "https://courtai.app/skills/injury-brief"}`),
  and four `tabs`:
  - **Games** (`layout: "tiles"`): one item per game, with `title` (the game and
    its spread), `subtitle` (who is out on both sides), `bullets` (each gainer as
    `[name, the figure]`), `body` (the read), `cards` and `sources`.
  - **Spots** (`layout: "rows"`): one item per spot, strongest first, with `tag`
    (its grade), `title` (the bet), `subtitle` (the price and game), `key` (the
    figure that carries it), `body` (the case), `watch` (what loses it), `cards`
    and `sources`.
  - **Watch list** (`layout: "list"`): one item per angle, with `title` and
    `key` (what would make it a case). Leave the tab out when it is empty.
  - **Set aside** (`layout: "list"`): one item per player, with `title` and `key`
    (why).
- `calls`: every call whose card the report shows, each as `{id, tool, args}`
  with the same arguments you called it with. An item's `cards` lists call ids,
  the one that carries it first.
- `show_author`: false unless the user asks to be named.

CourtAI reruns each call to draw its card, and the reruns count against your
daily limit, so list only calls you made, that drew a card, and that an item's
`cards` names. If the publish is refused, fix what it names and publish
again. Give the user the link it returns.

